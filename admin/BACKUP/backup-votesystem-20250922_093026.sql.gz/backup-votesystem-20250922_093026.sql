CREATE DATABASE IF NOT EXISTS `votesystem`;

USE `votesystem`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `admin` VALUES (1,"admin","$2y$10$ceE7pA/LCHBO4O52gc4.9.9fv3KEXAqKymG3bZQt5qxOAqXVAJBRW","McJim","Castillon","mcjim.jpg","2018-04-02");


DROP TABLE IF EXISTS `candidates`;

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position_id` int(11) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `platform` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO `candidates` VALUES (18,8,"Cong Ress","Man","","Project Source of Fund"),
(19,9,"Cont","Ractor","profile.jpg",""),
(20,10,"Kerida","Sanchez","profile.jpg","Fund Raiser, Budget Officer"),
(21,8,"Go","Bernor","","Budget Manager"),
(22,9,"Depart","Ment","","Flood Control Budget Slicer"),
(23,10,"Kadidang","Paldo","","Paldong-Paldo sa Gasto"),
(24,11,"Anak","Contractor","","Best in many waldas"),
(25,11,"Anak","Congressman","","Best in Overseas Tour");


DROP TABLE IF EXISTS `positions`;

CREATE TABLE `positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(50) NOT NULL,
  `max_vote` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `positions` VALUES (8,"Policians",2000,1),
(9,"Contractor",2000,2),
(10,"Kerida",1000,3),
(11,"Baby Girls",500,4);


DROP TABLE IF EXISTS `voters`;

CREATE TABLE `voters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voters_id` varchar(15) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `photo` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `voters` VALUES (2,"qDVmTUtxZw8a7RO","$2y$10$y82jur8k7676STpNUEqMkuIoyHw.LIhhuF9wIaDS9rHqBIuC7sczC","Voter","Name","profile.jpg"),
(3,"kq1t28xmyWNQlLg","$2y$10$QfNl33pIXamsHn6aCJL08OvFh7rI3RnzhgGqg/rUKff7F0H6B9jHq","Akona","Gudni",""),
(4,"kqQO7oZEKjSsfuF","$2y$10$wb9/F4ralQfgoy0mKrWcIuYyKGp7spDujQcdmsoXlLJ66qzQmr0pe","Ambot","Lang","");


DROP TABLE IF EXISTS `votes`;

CREATE TABLE `votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voters_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

INSERT INTO `votes` VALUES (81,2,18,8),
(82,2,19,9),
(83,2,20,10),
(84,3,21,8),
(85,3,19,9),
(86,3,23,10),
(87,3,25,11);


SET foreign_key_checks = 1;
